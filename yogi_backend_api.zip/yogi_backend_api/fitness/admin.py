from django.contrib import admin
from .models import FitnessClass, Booking

admin.site.register(FitnessClass)
admin.site.register(Booking)
